'use strict';

// Globals for all test_*.js files.
global.expect = require('chai').expect;
global.path = require('path');
global.SassyTest = require('sassy-test');
